# Stat386 Blog Theme

This is a simple and poorly documented Jekyll theme that I made for my Stat 386 class to use.  I built the theme originally by following the ["Up and Running with GitHub Pages" (parts 1 - 6)](https://www.youtube.com/playlist?list=PLWzwUIYZpnJuT0sH4BN56P5oWTdHJiTNq) tutorials by Bill Raymond on YouTube.
